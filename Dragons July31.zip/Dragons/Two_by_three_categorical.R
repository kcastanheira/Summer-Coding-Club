load("/Users/kevin/coding-club/dragons/dragons.RData")

library(ggplot2)  # load the package
library(dplyr)  # load the package
dragons$Female = as.numeric(dragons$Female)
dragons %>% dplyr::group_by(Female, site) %>% dplyr::summarize(Mean=mean(testScore), sem=sd(testScore)/sqrt(length(testScore))) %>%
ggplot( aes(x = Female, y = Mean, color=site)) +
  geom_point() + geom_line() +theme_minimal()

aggregate(testScore ~ Female+site, dragons, mean)

basic.lm1 <- lm(testScore ~ Female*site, data = dragons)
summary(basic.lm1)  

#the intercept is the difference between the mean of Males for site a
#Female is HOW MUCH LARGER the mean for females is for site a
#Site b is HOW MUCH LARGER the mean for males in site b is compared to a
#Site c is HOW MUCH LARGER the mean for males in site c is compared to a
#Female:siteb is HOW MUCH SMALLER the difference in the means for males in site a vs femlaes in site a is compared to males in site b vs femlaes in site b
# ANOTHER WAY OF PUTTING IT:
# HOW MUCH DID THE "SLOPE" BETWEE MALE vs FEMALE change between groups a and b

#Female:sitec is HOW MUCH SMALLER the difference in the means for males in site a vs femlaes in site a is compared to males in site c vs femlaes in site c
# ANOTHER WAY OF PUTTING IT:
# HOW MUCH DID THE "SLOPE" BETWEE MALE vs FEMALE change between groups a and c