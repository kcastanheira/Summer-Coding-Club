# https://gkhajduk.github.io/2017-03-09-mixed-models/

load("/Users/kevin/coding-club/dragons/dragons.RData")

hist(dragons$testScore) 
dragons$bodyLength2 <- scale(dragons$bodyLength)

library(lme4)
##### CATEGORICAL VS CONTINUOUS VARIABLE
##### LINEAR REGRESSION

######### LINEAR REGRESSION ###########
library(ggplot2)  # load the package
ggplot(dragons, aes(x = bodyLength2, y = testScore)) +
  geom_point() +
  geom_smooth(method = "lm") 

basic.lm <- lm(testScore ~ bodyLength2, data = dragons)
summary(basic.lm)

#### LINEAR REGRESSION ASSUMPTIONS
#Linearity & Homoscedasticity
plot(basic.lm, which = 1)
#Normaility of residuals
plot(basic.lm, which = 2)
#outliers
plot(basic.lm, which = 4)

#### LINEAR REGRESSION AS ANOVA ####
# WHAT IS THE NULL HYPOTHEIS FOR AN ANOVA?
# WHAT IS THE ALTERNATE HYPOTHESIS FOR AN ANOVA?
ggplot(dragons, aes(x = Female, y = testScore)) +
  geom_boxplot()  

basic.lm1 <- lm(testScore ~ Female, data = dragons)
summary(basic.lm1)

aggregate(testScore ~ Female, dragons, mean)

unique(dragons$mountainRange)

basic.lm2 <- lm(testScore ~ mountainRange, data = dragons)
summary(basic.lm2)

ggplot(dragons, aes(x = mountainRange, y = testScore)) +
  geom_boxplot() 

unique(dragons$site)

basic.lm2.0 <- lm(testScore ~ 0 + mountainRange, data = dragons)
summary(basic.lm2.0)
aggregate(testScore ~ mountainRange, dragons, mean)

basic.lm3 <- lm(testScore ~ site, data = dragons)
summary(basic.lm3)

ggplot(dragons, aes(x = site, y = testScore)) +
  geom_boxplot() 

basic.lm3.0 <- lm(testScore ~ 0+ site, data = dragons)
summary(basic.lm3.0)
aggregate(testScore ~ site, dragons, mean)

dragons$site_new = relevel(dragons$site, ref = "c")
basic.lm4 <- lm(testScore ~ site_new, data = dragons)
summary(basic.lm4)

######## DUMMY CODE ########
dragons$D1_A = as.numeric(dragons$site=="a")
dragons$D1_B = as.numeric(dragons$site=="b")

basic.lm4 <- lm(testScore ~ D1_A+D1_B, data = dragons)
summary(basic.lm4)

##### LINEAR MODEL INTERACTIONS ######
basic.lm5 <- lm(testScore ~  1+site*mountainRange, data = dragons)
summary(basic.lm5)

aggregate(testScore ~ site+mountainRange, dragons, mean)
v
basic.lm5 <- lm(testScore ~ 1+ Female + bodyLength, data = dragons)
summary(basic.lm5)

basic.lm5 <- lm(testScore ~ 1+ Female*bodyLength, data = dragons)
summary(basic.lm5)

ggplot(dragons, aes(x = bodyLength, y = testScore, color=Female)) +
  geom_point() +
  geom_smooth(method = "lm") + theme_minimal()

basic.lm5 <- lm(testScore ~ 1+ site + bodyLength, data = dragons)
summary(basic.lm5)

basic.lm5 <- lm(testScore ~ 1+  bodyLength*site, data = dragons)
summary(basic.lm5)

anova(basic.lm, basic.lm5)

ggplot(dragons, aes(x = bodyLength, y = testScore, color=site)) +
  geom_point() +
  geom_smooth(method = "lm") +facet_wrap(~site)


basic.lm5 <- lm(testScore ~ bodyLength2*mountainRange, data = dragons)
summary(basic.lm5)
 
ggplot(dragons, aes(x = bodyLength2, y = testScore, color=mountainRange)) +
  geom_point() + geom_smooth(method="lm") + facet_wrap(~mountainRange)
########### LMER ##########

mixed.lmer <- lmer(testScore ~ bodyLength2 + (1|mountainRange), data = dragons)
summary(mixed.lmer)

mixed.lmer1 <- lmer(testScore ~ bodyLength2 + (1 + bodyLength2 |mountainRange), data = dragons)
summary(mixed.lmer1)

coef(mixed.lmer1)

ggplot(dragons, aes(x = bodyLength2, y = testScore, color=mountainRange)) +
  geom_point() + geom_smooth(method="lm") + facet_wrap(~mountainRange)

#### CROESSED MIXED EFFECTS ####
load("/Users/kevin/coding-club/dragons/dragons_Kevin.RData")
dragons_kevin$PID = as.factor(dragons_kevin$PID)

ggplot(dragons_kevin[dragons_kevin$mountainRange=="Bavarian",], aes(x = bodyLength, y = testScore, color=PID)) +
  geom_point() + geom_smooth(method="lm") + facet_wrap(~mountainRange) +theme(legend.position = "none")

mixed.lmer2 <- lmer(testScore ~ bodyLength + (1 |mountainRange) + (1 |PID), data = dragons_kevin)  # the syntax stays the same, but now the nesting is taken into account
summary(mixed.lmer2)


###### NESTED MIXED EFFECTS ########
ggplot(dragons, aes(x = bodyLength2, y = testScore, color=site)) +
  geom_point() + geom_smooth(method="lm") + facet_wrap(~mountainRange)

dragons$sample <- interaction(dragons$mountainRange, dragons$site)

mixed.lmer3 <- lmer(testScore ~ bodyLength2 + (1|mountainRange) + (1|sample), data = dragons)  # the syntax stays the same, but now the nesting is taken into account
summary(mixed.lmer3)

